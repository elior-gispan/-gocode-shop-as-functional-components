import React from "react";

class ProductsFilter extends React.Component {
  state = { value: "All Products" };

  handleChange = (event) => {
    const Products = this.props.children;
    this.setState({ value: event.target.value });
    if (this.state.value !== "All Products") {
      const FilteredProducts = Products.filter(
        (product) => product.category === this.state.value
      );
      console.log(FilteredProducts);
      this.props.ProductsUpdate(FilteredProducts);
    }
  };

  handleChange = (event) => {
    const Products = this.props.children;
    this.setState({ value: event.target.value });
    if (this.state.value !== "All Products") {
      const FilteredProducts = Products.filter(
        (product) => product.category === event.target.value
      );
      console.log(FilteredProducts);
      this.props.ProductsUpdate(FilteredProducts);
    }
  };

  render() {
    const OptionsList = this.props.categories.map((category) => {
      return (
        <option key={category} value={category}>
          {category}
        </option>
      );
    });
    // const ProductsList = this.props.children.map(
    //   ({ title, price, image, id }) => (
    //     <Product
    //       title={title}
    //       price={price}
    //       imgSrc={image}
    //       key={id}
    //       productClassName={
    //         this.state.onSaleIdProducts.includes(id) ? "onSale" : "product-card"
    //       }
    //     />
    //   )
    // );

    return (
      <div className="collection-sort">
        <label>Filter by:</label>
        <select value={this.state.value} onChange={this.handleChange}>
          <option value="All Products">All Products</option>
          {OptionsList}
        </select>
      </div>
    );
  }
}

export default ProductsFilter;
