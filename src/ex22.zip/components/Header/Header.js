import React from "react";
import ProductsFilter from "../ProductsFilter/ProductsFilter";
import ProductsSort from "../ProductsSort/ProductsSort";

class Header extends React.Component {
  render() {
    return (
      <nav className="product-filter">
        <h1>Products</h1>
        <div className="sort">
          <ProductsFilter
            categories={this.props.categories}
            productsUpdate={this.props.ProductsUpdate}
          >
            {this.props.children}
          </ProductsFilter>
          <ProductsSort />
        </div>
      </nav>
    );
  }
}

export default Header;
